DUMITRASCU CATALIN-NICOLAE
333CC

TEMA 2 - APD;

Am folosit un concurrentHashMap pentru a pastra mesajele primite de la Wizards. Fiecare Wizard are threadID-ul sau unic, care este cheia lui in hashmap, si un array de mesaje, care este lista cu mesaje. 

Pentru ca minerii sa citeasca mesajele, am iterat prin key-urile lor, returnand primele 2 mesaje de la primul key gasit.

Prima oara am incercat sa folosesc alt ArrayBlockingQueue, in care adaugam toate mesajele primite de la toti minerii, dar din pacate varianta aceasta nu termina in 30 de secunde.

PS: Ciudata tema, am stat cel putin 6 ore sa-mi dau seama de ce imi aparea HOMEWORK DOES NOT COMPILE. Si inca nu sunt sigur :)))))
PS2: Se poate scuza depuncatarea pentru atat de putin timp? :3